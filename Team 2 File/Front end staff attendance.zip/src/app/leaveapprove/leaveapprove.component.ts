import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { LeavedetailService, leavedetail } from '../service/leavedetail.service';
import { UseraccountService } from '../service/useraccount.service';
import { AttendancedetailService } from '../service/attendancedetail.service';

@Component({
  selector: 'app-leaveapprove',
  templateUrl: './leaveapprove.component.html',
  styleUrls: ['./leaveapprove.component.css']
})
export class LeaveapproveComponent implements OnInit {
  public aleave:leavedetail
  public empleave:leavedetail[]
  message:string;
  empid:string;
  fromdate:string;
  todate:string;
  constructor(private atten:AttendancedetailService,private userService: UseraccountService,private leave:LeavedetailService) {

    
    this.userService.currentMessage.subscribe(message => this.message = message)
    this.leave.getDept(this.message)
    .subscribe( (data) => {
      console.log(JSON.stringify(data))
      
      this.empleave = data as leavedetail[]
    }
    );
   }

  ngOnInit() {
  }
  acc(get:leavedetail){
    this.userService.currentMessage.subscribe(message => this.message = message)
    this.leave.updatedept(get.employeeId,get.fromdate,"yes")
    .subscribe( (data) => {
      console.log("VANDURU"+JSON.stringify(data))
      
      this.empleave = data as leavedetail[]
    }
    );
this.atten.updateatten(get.employeeId,false,Number(get.fromdate));
  }
  rej(get:leavedetail){
    this.userService.currentMessage.subscribe(message => this.message = message)
    this.leave.updatedept(get.employeeId,get.fromdate,"no")
    .subscribe( (data) => {
      console.log(JSON.stringify(data))
      
      this.empleave = data as leavedetail[]
    }
    );
    this.atten.updateatten(get.employeeId,true,Number(get.fromdate));

  }
}
