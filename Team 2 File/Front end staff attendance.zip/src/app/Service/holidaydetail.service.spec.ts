import { TestBed } from '@angular/core/testing';

import { HolidaydetailService } from './holidaydetail.service';

describe('HolidaydetailService', () => {
  let service: HolidaydetailService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(HolidaydetailService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
