import { TestBed } from '@angular/core/testing';

import { AttendancedetailService } from './attendancedetail.service';

describe('AttendancedetailService', () => {
  let service: AttendancedetailService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AttendancedetailService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
