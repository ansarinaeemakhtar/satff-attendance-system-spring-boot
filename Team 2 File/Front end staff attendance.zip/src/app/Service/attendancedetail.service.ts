import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
export class attendace{
  constructor( 
    public id:number,
		public employeeId:string,
		public month:string,
		public date:number,
		public departmentId:string,
		public available:boolean,
		public checkin:string,
		public checkout:string
){}
}
@Injectable({
  providedIn: 'root'
})
export class AttendancedetailService {

  constructor(private http:HttpClient) { }

  getattendance(atten:string) {
    console.log("FREE");
    return this.http.get<attendace[]>("http://localhost:8081/attendancedetail/findbyempidatten?employeeid="+ atten);
}
getcountempdeptavail(emp:string,dept:string,avail:Boolean){
  return this.http.get<attendace[]>('http://localhost:8081/attendancedetail/findbyEandDandA?employeeid='+emp+'&departmentid='+dept+'&available='+avail);

}
getcountempdept(emp:string,dept:string){
  return this.http.get<attendace[]>('http://localhost:8081/attendancedetail/findbyEandD?employeeid='+emp+'&departmentid='+dept);

}
getcountdeptmonth(dept:string,month:string){
  return this.http.get<number>('http://localhost:8081/attendancedetail/findbyDandm?employeeid='+dept+'&month='+month);
}

getcountdeptmonthavail(dept:string,month:string,avail:Boolean){
  return this.http.get<number>('http://localhost:8081/attendancedetail/findbyDandmanda?employeeid='+dept+'&month='+month+'&available='+avail);
}

updateatten(emp:string,avail:Boolean,date:number){
  return this.http.get<string>('http://localhost:8081/attendancedetail/updateatten?employeeid='+emp+'&available='+avail+'&date='+date);
}

getsorteddept(dept:string,month:string){
  return this.http.get<string[]>('http://localhost:8081/attendancedetail/sortview?departmentId='+dept+'&month='+month);
}
}
