import { TestBed } from '@angular/core/testing';

import { DepartmentdetailService } from './departmentdetail.service';

describe('DepartmentdetailService', () => {
  let service: DepartmentdetailService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DepartmentdetailService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
