import { Component, OnInit } from '@angular/core';
import { UseraccountService } from '../service/useraccount.service';
import { AttendancedetailService, attendace } from '../service/attendancedetail.service';

@Component({
  selector: 'app-deptatten',
  templateUrl: './deptatten.component.html',
  styleUrls: ['./deptatten.component.css']
})
export class DeptattenComponent implements OnInit {
  message:string;
  public month=''
  public year=''
  showActions: boolean = false;  
count:number
  public atten:attendace
public at:string[]
  constructor(private attendance:AttendancedetailService,private userService: UseraccountService) {
    this.userService.currentMessage.subscribe(message => this.message = message)
    //this.attendance.getsorteddept
   }
   
  ngOnInit() {
  }
  submit(){
    this.attendance.getsorteddept(this.message.toString(),this.month)
    .subscribe( (data) => {
      console.log(JSON.stringify(data))
      
      this.at = data as string[];
      this.showActions=true;

    }
    );
    this.attendance.getcountempdeptavail(this.message.toString(),this.month,true)
    .subscribe( (data) => {
      console.log(JSON.stringify(data))
      
      this.count = Number(data)
      this.showActions=true;

    }
    );
    this.month=''
    this.year=''

  }
}
