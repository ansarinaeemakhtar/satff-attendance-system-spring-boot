import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { AdminComponent } from './admin/admin.component';
import { DepartmentComponent } from './department/department.component';
import { EmployeeComponent } from './employee/employee.component';
import { AuthGuard } from './auth.guard';
import { LeaveapplyComponent } from './leaveapply/leaveapply.component';
import {AttendanceempComponent} from './attendanceemp/attendanceemp.component'
import { NotificationempComponent } from './notificationemp/notificationemp.component';
import { HolidayempComponent } from './holidayemp/holidayemp.component';
import { LeaveapproveComponent } from './leaveapprove/leaveapprove.component';
import { DeptattenComponent } from './deptatten/deptatten.component';
import { AdminattenComponent } from './adminatten/adminatten.component';
import { AdminholidayComponent } from './adminholiday/adminholiday.component';
import { ViewemployeeComponent } from './viewemployee/viewemployee.component';
import { AdminempComponent } from './adminemp/adminemp.component';
import { HomeComponent } from './home/home.component';

export const routes: Routes = [
    { path: '', pathMatch: "full", redirectTo: '/home' },
    { path: 'home', component: HomeComponent },
    { path: 'applyleave', component: LeaveapplyComponent },
    { path: 'employee', component: AttendanceempComponent },
    { path: 'notification', component: NotificationempComponent },
    { path: 'holiday', component: HolidayempComponent },
    { path: 'department', component: DeptattenComponent },
    { path: 'approve', component: LeaveapproveComponent },
    // { path: 'adminhol', component: AdminholidayComponent },
    // { path: 'viewemp', component: ViewemployeeComponent },
    // { path: 'adminemp', component: AdminempComponent },

    { path: 'adminatten', component: AdminattenComponent },
    { 
      path: 'login', 
      component: LoginComponent,
      canActivate:[AuthGuard]
   },
    {
      path: 'admin',
      component: AdminComponent,
      canActivate:[AuthGuard]
     /* children:[
        { path: 'createemployee', component: LoginComponent },
        { path: '', component: LoginComponent },
        { path: 'overallattendance', component: LoginComponent },
      ]*/
     
    },
    {
      path: 'dept',
      component: DepartmentComponent,
      canActivate:[AuthGuard]
      
    },
    { 
      path: 'emp',
      component: EmployeeComponent,
      canActivate:[AuthGuard],
      children:[
        { path: 'attendance', component: LoginComponent },
        { path: 'salary', component: LoginComponent },
        { path: 'overallattendance', component: LoginComponent },
        
      ]
    },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
