export interface Employee{
    employeeId:string,
    password:string,
    type:string
}