import { Component, OnInit } from '@angular/core';
import { UseraccountService } from '../service/useraccount.service';
import { Router, ActivatedRoute } from '@angular/router';
import { EmployeedetailService, employeedetail } from '../service/employeedetail.service';
import { department, DepartmentdetailService } from '../service/departmentdetail.service';

@Component({
  selector: 'app-adminemp',
  templateUrl: './adminemp.component.html',
  styleUrls: ['./adminemp.component.css']
})
export class AdminempComponent implements OnInit {
  private de:department
  private depart:department[]
  private department=''
  public employee:employeedetail;
  public emp:string;
  public employeename:string[];
  public show = false
  constructor(private dept:DepartmentdetailService,private userService: UseraccountService,private router: Router,private route:ActivatedRoute,private employeeservice : EmployeedetailService){
  }

  ngOnInit() {
  }
  submit(){
    this.dept.findalldepartment()
    .subscribe( (data) => {
      console.log(JSON.stringify(data))
      
      this.depart = data as department[];
    }
    );
  
   this.employeeservice.getempbydept(this.department)
   .subscribe((data)=>{
     this.employeename = data
   })
  
    this.employeeservice.getEmployee(this.emp)
    .subscribe( (data) => {
      console.log(JSON.stringify(data)) 
      this.employee = data
  }
    );
    this.show=true;
  }
}
