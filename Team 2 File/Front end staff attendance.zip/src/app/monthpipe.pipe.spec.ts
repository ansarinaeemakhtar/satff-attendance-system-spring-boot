import { MonthpipePipe } from './monthpipe.pipe';

describe('MonthpipePipe', () => {
  it('create an instance', () => {
    const pipe = new MonthpipePipe();
    expect(pipe).toBeTruthy();
  });
});
